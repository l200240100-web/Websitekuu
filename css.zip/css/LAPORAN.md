# LAPORAN PROYEK WEBSITE PORTFOLIO
## Qonita Azizah – Website Profi Qonita

---

## 1. Deskripsi Proyek

### Tujuan
Proyek ini bertujuan untuk membuat sebuah website **portfolio pribadi** milik Qonita Azizah yang menampilkan informasi diri, pengalaman, proyek, dan kontak secara profesional dan menarik secara visual. Website ini digunakan sebagai media presentasi diri di dunia digital, khususnya sebagai mahasiswa Teknik Informatika yang memiliki ketertarikan di bidang Desain Grafis.

### Fitur Utama
- **Halaman Home** – Menampilkan nama dan identitas singkat pemilik portfolio (Qonita Azizah, Mahasiswa Teknik Informatika – Universitas Muhammadiyah Surakarta).
- **Halaman Portfolio** – Berisi bio singkat, yang berisis tentang pengalaman belajar , serta galeri proyek yang pernah dikerjakan.
- **Halaman Contact** – Menyediakan informasi kontak lengkap berupa alamat, nomor telepon, dan email.
- **Navigasi responsif** – Header dengan logo dan menu navigasi yang konsisten di semua halaman.
- **Tipografi elegan** – Menggunakan kombinasi font *Playfair Display* (serif dekoratif) dan *DM Sans* (sans-serif modern) dari Google Fonts.

### Teknologi yang Digunakan
| Teknologi | Keterangan |
|-----------|------------|
| HTML5 | Struktur dan konten halaman web |
| CSS3 | Styling dan layout (file `style.css`) |
| Google Fonts | Font `Playfair Display` dan `DM Sans` |
| GitHub Pages | Platform hosting website statis |
| Git & GitHub | Version control dan repository |

---

## 2. Struktur Folder dan File

```
repository/
│
├── index.html          # Halaman utama (Home)
├── portfolio.html      # Halaman portfolio
├── contact.html        # Halaman Contact
├── style.css           # File stylesheet utama
├── aku.jpeg            # Foto Qonita Azizah
├── Project1.png        # Foto Project1
├── Project2.png        # Gambar Project3
├── Project3.png        # Gambar Project2
└── LAPORAN.md          # Laporan proyek ini
```

---

## 3. Link Website

> 🌐 **URL Website:** [https://l200240080.github.io/Alama/]

Website telah berhasil di-hosting menggunakan **GitHub Pages** dan dapat diakses secara publik melalui link di atas.

---

## 4. Tangkapan Layar Bukti SSH Berhasil Dikonfigurasi

> 📸 *Lampirkan tangkapan layar hasil perintah berikut di sini:*

```bash
ssh -T git@github.com
```

**Contoh output yang diharapkan:**
```
Hi l200240100-web! You've successfully authenticated, but GitHub does not provide shell access.
```

> ⚠️ **Catatan:** Tambahkan screenshot hasil perintah `ssh -T git@github.com` dari terminal kamu di bagian ini.

---

## 5. Tangkapan Layar Hasil Validasi W3C HTML dan CSS

### Validasi HTML (W3C Markup Validation Service)
- **Tool:** [https://validator.w3.org](https://validator.w3.org)
- **File yang divalidasi:** `index.html`, `about.html`, `contact.html`

> ⚠️ **Catatan:** Tambahkan screenshot hasil validasi HTML dari https://validator.w3.org di bagian ini.

### Validasi CSS (W3C CSS Validation Service)
- **Tool:** [https://jigsaw.w3.org/css-validator](https://jigsaw.w3.org/css-validator)
- **File yang divalidasi:** `style.css`

> ⚠️ **Catatan:** Tambahkan screenshot hasil validasi CSS dari https://jigsaw.w3.org/css-validator di bagian ini.

---

## 6. Catatan Tambahan

- Website menggunakan semantik HTML5 yang baik (`<header>`, `<main>`, `<article>`, `<section>`, `<figure>`, `<address>`, `<hgroup>`, dll.)
- Semua halaman memiliki struktur navigasi yang konsisten.
- Meta tag `description` telah ditambahkan pada setiap halaman untuk mendukung SEO dasar.
- Bahasa halaman menggunakan atribut `lang="id"` sesuai konten berbahasa Indonesia.

---

*Laporan ini dibuat sebagai bagian dari tugas pembuatan website portfolio menggunakan GitHub Pages.*
